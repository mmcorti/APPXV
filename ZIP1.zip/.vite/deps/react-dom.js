import {
  require_react_dom
} from "./chunk-RPXCWSQR.js";
import "./chunk-KXFOPGTJ.js";
import "./chunk-5WRI5ZAA.js";
export default require_react_dom();

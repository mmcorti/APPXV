declare const Object: ObjectConstructor;

export = Object;

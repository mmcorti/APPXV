'use strict';

/** @type {import('.')} */
module.exports = Object;

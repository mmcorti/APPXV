import { AsyncScheduler } from './AsyncScheduler';

export class QueueScheduler extends AsyncScheduler {
}
